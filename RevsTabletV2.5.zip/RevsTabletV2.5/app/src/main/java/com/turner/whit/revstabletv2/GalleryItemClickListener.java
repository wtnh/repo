package com.turner.whit.revstabletv2;

import android.widget.ImageView;

public interface GalleryItemClickListener {
    void onGalleryItemClickListener(int position, ImageModel imageModel, ImageView imageView);
}
