# RevsTabletV2.3Release
This is an Android app for volunteers at the Revs Institiute for Automotive Research, a non-profit museum
housing a collection of rare and antique vehicles located in Naples, Florida USA.
The app is configured with a JSON file located at https://github.com/wtnh/repo/blob/master/revs_tablet_config1.json
The target device is currently a Samsung Galaxy A 7" tablet.

First actual release is Build 10 - August 26, 2019 for deployment on multiple devices

Here is a brief demo (unfortunately the clicks are not visible and gif has color artifacts):

![Revs Tablet Demo](https://github.com/wtnh/repo/blob/master/demo1.gif)
